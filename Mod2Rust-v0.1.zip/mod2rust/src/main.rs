use serde::Serialize;
use serde_json::Value;
use std::{env, fs::File, io::Read, path::Path, process};
use zip::ZipArchive;

const MAX_ENTRIES: usize = 100_000;
const MAX_METADATA_BYTES: u64 = 2 * 1024 * 1024;

#[derive(Debug, Serialize)]
struct ModReport {
    tool: &'static str,
    tool_version: &'static str,
    input_file: String,
    format: &'static str,
    mod_id: Option<String>,
    name: Option<String>,
    version: Option<String>,
    description: Option<String>,
    environment: Option<String>,
    minecraft_dependency: Option<Value>,
    dependencies: Value,
    entrypoints: Value,
    mixin_configs: Vec<String>,
    access_wideners: Vec<String>,
    nested_jars: Vec<String>,
    class_count: usize,
    class_file_versions: Vec<u16>,
    resource_count: usize,
    warnings: Vec<String>,
}

fn main() {
    if let Err(message) = run() {
        eprintln!("Mod2Rust error: {message}");
        eprintln!("Usage: mod2rust inspect <mod.jar> [report.json]");
        process::exit(1);
    }
}

fn run() -> Result<(), String> {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.len() < 2 || args[0] != "inspect" {
        return Err("expected the 'inspect' command and a JAR path".into());
    }

    let input = &args[1];
    let path = Path::new(input);
    if !path.is_file() {
        return Err(format!("input file does not exist: {input}"));
    }

    let file = File::open(path).map_err(|e| format!("cannot open JAR: {e}"))?;
    let mut archive = ZipArchive::new(file).map_err(|e| format!("invalid ZIP/JAR archive: {e}"))?;
    if archive.len() > MAX_ENTRIES {
        return Err(format!("archive contains too many entries ({})", archive.len()));
    }

    let metadata_text = {
        let mut metadata = archive
            .by_name("fabric.mod.json")
            .map_err(|_| "fabric.mod.json was not found at the JAR root; this prototype currently supports Fabric mods".to_string())?;
        if metadata.size() > MAX_METADATA_BYTES {
            return Err("fabric.mod.json is unexpectedly large".into());
        }
        let mut text = String::new();
        metadata
            .read_to_string(&mut text)
            .map_err(|e| format!("cannot read fabric.mod.json: {e}"))?;
        text
    };

    let manifest: Value = serde_json::from_str(&metadata_text)
        .map_err(|e| format!("fabric.mod.json is not valid JSON: {e}"))?;

    let mut mixin_configs = Vec::new();
    let mut access_wideners = Vec::new();
    let mut nested_jars = Vec::new();
    let mut class_count = 0usize;
    let mut resource_count = 0usize;
    let mut class_file_versions = Vec::new();

    for index in 0..archive.len() {
        let mut entry = archive.by_index(index).map_err(|e| format!("cannot inspect archive entry: {e}"))?;
        let name = entry.name().to_string();
        if name.ends_with(".class") {
            class_count += 1;
            // A class file starts with CAFEBABE, followed by minor and major versions.
            let mut header = [0u8; 8];
            if entry.read_exact(&mut header).is_ok() && header[0..4] == [0xCA, 0xFE, 0xBA, 0xBE] {
                let major = u16::from_be_bytes([header[6], header[7]]);
                if !class_file_versions.contains(&major) {
                    class_file_versions.push(major);
                }
            }
        } else {
            resource_count += 1;
        }

        if name.ends_with(".mixins.json") || name.ends_with(".mixin.json") {
            mixin_configs.push(name.clone());
        }
        if name.ends_with(".accesswidener") {
            access_wideners.push(name.clone());
        }
        if name.ends_with(".jar") && name.starts_with("META-INF/jars/") {
            nested_jars.push(name);
        }
    }

    class_file_versions.sort_unstable();
    let mut warnings = Vec::new();
    if !mixins_from_manifest(&manifest).is_empty() || !mixin_configs.is_empty() {
        warnings.push("Mixin configuration detected: bytecode injections need dedicated translation rules.".into());
    }
    if !access_wideners.is_empty() || manifest.get("accessWidener").is_some() {
        warnings.push("Access widener detected: Minecraft access changes are not translated in v0.1.".into());
    }
    if !nested_jars.is_empty() {
        warnings.push("Nested JAR dependencies detected: each nested mod/library needs separate analysis.".into());
    }
    if manifest.get("entrypoints").is_some() {
        warnings.push("Java entrypoints detected: their behavior is listed but not executed or translated yet.".into());
    }

    let report = ModReport {
        tool: "Mod2Rust",
        tool_version: env!("CARGO_PKG_VERSION"),
        input_file: input.clone(),
        format: "fabric-mod-analysis",
        mod_id: string_field(&manifest, "id"),
        name: string_field(&manifest, "name"),
        version: value_to_string(manifest.get("version")),
        description: string_field(&manifest, "description"),
        environment: string_field(&manifest, "environment"),
        minecraft_dependency: manifest.get("depends").and_then(|v| v.get("minecraft")).cloned(),
        dependencies: manifest.get("depends").cloned().unwrap_or(Value::Null),
        entrypoints: manifest.get("entrypoints").cloned().unwrap_or(Value::Null),
        mixin_configs,
        access_wideners,
        nested_jars,
        class_count,
        class_file_versions,
        resource_count,
        warnings,
    };

    let json = serde_json::to_string_pretty(&report).map_err(|e| format!("cannot serialize report: {e}"))?;
    if let Some(output) = args.get(2) {
        std::fs::write(output, &json).map_err(|e| format!("cannot write report: {e}"))?;
        println!("Analysis complete. Report written to {output}");
    } else {
        println!("{json}");
    }
    Ok(())
}

fn string_field(value: &Value, key: &str) -> Option<String> {
    value.get(key).and_then(Value::as_str).map(str::to_owned)
}

fn value_to_string(value: Option<&Value>) -> Option<String> {
    match value? {
        Value::String(s) => Some(s.clone()),
        other => Some(other.to_string()),
    }
}

fn mixins_from_manifest(manifest: &Value) -> Vec<String> {
    match manifest.get("mixins") {
        Some(Value::Array(items)) => items.iter().filter_map(|item| {
            if let Some(s) = item.as_str() { Some(s.to_owned()) }
            else { item.get("config").and_then(Value::as_str).map(str::to_owned) }
        }).collect(),
        _ => Vec::new(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_string_and_numeric_versions() {
        let value: Value = serde_json::json!({"id":"demo", "version": 3});
        assert_eq!(string_field(&value, "id").as_deref(), Some("demo"));
        assert_eq!(value_to_string(value.get("version")).as_deref(), Some("3"));
    }

    #[test]
    fn recognizes_mixin_config_forms() {
        let value: Value = serde_json::json!({"mixins":["a.mixins.json", {"config":"b.mixins.json"}]});
        assert_eq!(mixins_from_manifest(&value), vec!["a.mixins.json", "b.mixins.json"]);
    }
}
