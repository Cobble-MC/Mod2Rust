# Mod2Rust

Mod2Rust is an experimental Java-to-Rust Minecraft mod conversion project. Version 0.1 is a **read-only Fabric JAR analyzer**. It does not execute Java code and does not yet translate bytecode into Rust.

## Current scope

- Opens a Fabric mod `.jar` as a ZIP archive.
- Reads `fabric.mod.json`.
- Reports mod identity, version, environment, Minecraft dependency, dependencies and entrypoints.
- Counts `.class` files and records their class-file major versions.
- Detects mixin configs, access wideners and nested JARs.
- Writes a JSON report.

## Build

Requires a Rust stable toolchain. The GitHub Actions workflow builds Linux x86_64 and Android ARM64 binaries in the cloud.

```sh
cargo test
cargo build --release
```

## Run

```sh
./target/release/mod2rust inspect path/to/mod.jar
./target/release/mod2rust inspect path/to/mod.jar report.json
```

## Safety and limitations

The analyzer treats the JAR as data: it never loads or executes classes. It limits the archive entry count and metadata size. This is an early prototype, not a compatibility guarantee. A successful report does not mean the mod can already run in a Rust Minecraft client.

## Roadmap

1. Parse Java class-file structures (constant pool, fields, methods and attributes).
2. Build an intermediate representation for a carefully limited Java subset.
3. Translate supported bytecode patterns into Rust.
4. Add a Rust-side mod API and Minecraft 26.3 compatibility layer.
5. Add fixtures and differential tests for each supported feature.

Minecraft target: 26.3 / Fabric. The analyzer currently reads Fabric metadata generically; it does not yet validate every 26.3 API symbol.
